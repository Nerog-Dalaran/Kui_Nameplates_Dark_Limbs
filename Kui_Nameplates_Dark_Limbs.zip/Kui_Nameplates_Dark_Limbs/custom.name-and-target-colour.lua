local folder,ns=...
local addon = KuiNameplates
local core = KuiNameplatesCore
local mod = addon:NewPlugin('ColourBarByName',101)

local names = {
	-- Skorpyron
    ["Scorpide instable"] = {1,0,1},
	-- Tichondrius
	["Paresort gangrelige"] = {1,0,1},
	["Guetteur aveugle"] = {1,0,1},
	-- Botaniste
	["Flagellant parasite"] = {1,0,1},
	["Sphère de plasma"] = {1,0,1},
	-- Guldan
	["Oeil de Gul’dan"] = {1,0,1},
	["Oeil de Gul’dan surpuissant"] = {1,0,1},
	["Inquisiteur Vethriz"] = {1,0,1},
}

local PRIORITY = 3

local function CanOverwriteHealthColor(f)
    return not f.state.health_colour_priority or
           f.state.health_colour_priority <= PRIORITY
end

function mod:NameUpdate(frame)
    if COLOUR_TARGET and frame.handler:IsTarget() then return end

    local col = frame.state.name and names[frame.state.name]

    if not col and frame.state.bar_is_name_coloured then
        frame.state.bar_is_name_coloured = nil

        if CanOverwriteHealthColor(frame) then
            frame.state.health_colour_priority = nil
            frame.HealthBar:SetStatusBarColor(unpack(frame.state.healthColour))
        end
    elseif col then
        if CanOverwriteHealthColor(frame) then
            frame.state.bar_is_name_coloured = true
            frame.state.health_colour_priority = PRIORITY

            frame.HealthBar:SetStatusBarColor(unpack(col))
        end
    end
end
function mod:UNIT_NAME_UPDATE(event,frame)
    self:NameUpdate(frame)
end
function mod:GainedTarget(frame)
    if not COLOUR_TARGET then return end
    if CanOverwriteHealthColor(frame) then
        frame.state.bar_is_name_coloured = true
        frame.state.health_colour_priority = PRIORITY
        frame.HealthBar:SetStatusBarColor(unpack(COLOUR_TARGET))
    end
end

function mod:Initialise()
    self:RegisterMessage('Show','NameUpdate')
    self:RegisterMessage('HealthColourChange','NameUpdate')
    self:RegisterMessage('LostTarget','NameUpdate')
    self:RegisterUnitEvent('UNIT_NAME_UPDATE')

    self:RegisterMessage('GainedTarget','TargetUpdate')
end
